Sticky Note

Yan Cui
theburningmonk@gmail.com

2011-03-01

INTRO:

This is a simple sticky note application which allows you to create random coloured sticky notes and
write stuffs on them, and save them of course!

LIVE DEMO:

You can try the live demo at http://stickynote.theburningmonk.com or http://bit.ly/Ygflem.

THIRD-PARTY LIBRARIES:
* jQuery (in js/jquery)
* Douglas Crockford's JSON-js (in js)

CSS:
* main.css: This file contains all the CSS settings for the game

HTML:
* sticky_note_demo.html: This file contains all the HTML markup for the application, as well as all
the javascript for the app
